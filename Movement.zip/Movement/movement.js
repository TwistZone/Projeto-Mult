"use strict";

(function()
{
    window.addEventListener("load", main);
}());
function main() {
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");  //get content
    var personagem = new Personagem("Psicologia", "right");
    var imgArray = personagem.images;
    canvas.addEventListener("initend", initEndHandler);
    init(ctx, imgArray);  //carregar todos os componentes


    function initEndHandler(ev) {
        //instalar listeners das teclas
        window.addEventListener('keyup', kuh);
        window.addEventListener('keydown', kdh);
        personagem.sprites = ev.spArray;
        personagem.spriteCurr = personagem.sprites[7];
        console.log(personagem.spriteCurr);
        startAnim(ctx,personagem);
    }

    var kuh = function (ev) {
        canvasKeyUpHandler(ev,personagem);
    };
    var kdh = function (ev) {
        canvasKeyDownHandler(ev,personagem);
    };
}
function draw(ctx, sprite) {
        sprite.draw(ctx);
}
function startAnim(ctx, personagem) {
        draw(ctx,personagem.spriteCurr);
        animLoop(ctx, personagem);
    }
function init(ctx,chArray) {

    var nLoad = 0;
    var totLoad = chArray.length;
    var imgArray = new Array(totLoad);
    var n = 0;
    for (let i = 0; i < totLoad; i++) {
        imgArray[i] = new Image();
        imgArray[i].addEventListener("load", imgLoadedHandler);
        imgArray[i].id = n++;
        imgArray[i].src = chArray[i];
    }


    //var som to add later


    function imgLoadedHandler(ev) {
        var img = ev.target;
        var nw = img.naturalWidth;
        var nh = img.naturalHeight;
        if(img.id <= totLoad -1)
            imgArray[img.id] = new SpriteImage(500, 325, nw /3, nh /3, 10, img);
        else
            imgArray[img.id] = new SpriteImage(null, 310, nw /6, nh /6, 20, img);
        nLoad++;
        if (nLoad == totLoad) {
            var ev2 = new Event("initend");
            ev2.spArray = imgArray;
            ctx.canvas.dispatchEvent(ev2);
        }
    }
}

function animLoop(ctx, personagem) {
    var fps; // requestAnimationFrame default = 60
    if (personagem.spriteCurr.punch )
        fps = 10;
    else if(personagem.spriteCurr.special)
        fps = 3;
    else fps = 45;
    console.log(fps);
    var al = function(time)
    {
        animLoop(ctx, personagem);
    };
    var reqID = setTimeout(function(){window.requestAnimationFrame(al)},1000/fps);

    render(ctx, personagem,reqID);
}

function render(ctx, personagem,reqID) {
    const cw = ctx.canvas.width;
    const ch = ctx.canvas.height;
    const sp = personagem.spriteCurr;
    const bullet = personagem.sprites[14];
    var spArray = [sp];
    if(bullet.x === null)
        if(personagem.lado === "right")
            bullet.x = sp.x - 5 ;
        else
            bullet.x = sp.x + 5;
    ctx.clearRect(0, 0, cw, ch);
    //console.log(sp.kick + "PONTAPE");
    //console.log(sp.punch + "MURRO");
    console.log(sp.left + " left");
    console.log(sp.right + " right");
    if(sp.left && sp.x >0){
            sp.x -= sp.speed;
            personagem.walk();
    }
    if (sp.right && sp.x < cw) {
            sp.x += sp.speed;
            personagem.walk();
    }
    if (sp.up) {
        const yMax = 250;
        if(sp.y > yMax && !sp.descend)
            sp.y -= sp.speed;
        else if(sp.y === yMax)
            sp.descend = true;
        else if(sp.y < sp.yIni) {
            sp.descend = true;
            sp.y += sp.speed * 2;
        }
        personagem.jump();
    }
    if (sp.down)
        personagem.defend();
    if (sp.kick)
        personagem.kick();
    if (sp.punch)
        personagem.punch();
    if(sp.special){
        personagem.throw();
        bullet.bullet = true;
    }
    if(bullet.bullet) {
        const range = 20;
        spArray.push(bullet);
        if (bullet.bulletTime < range)
            if (personagem.lado === "right")
                bullet.x -= bullet.speed;
            else
                bullet.x += bullet.speed;
        else if(bullet.bulletTime === range)
            bullet.bullet = false;
        bullet.bulletTime++;
    }
    if(!sp.left && !sp.right && !sp.up && !sp.down && !sp.kick && !sp.punch && !sp.special)
        personagem.standard();
    draw(ctx,sp);
}
function canvasKeyDownHandler(ev,personagem) {
    let sp = personagem.spriteCurr;
    switch (ev.code) {
        case "ArrowLeft":
            sp.left = true;
            sp.right = false;
            personagem.falsify();
            break;
        case "KeyA":
            sp.left = true;
            sp.right = false;
            personagem.falsify();
            break;
        case "ArrowRight":
            sp.right = true;
            sp.left = false;
            personagem.falsify();
            break;
        case "KeyD":
            sp.right = true;
            sp.left = false;
            personagem.falsify();
            break;
        case "ArrowUp":
            sp.up = true;
            break;
        case "KeyW":
            sp.up = true;
            break;
        case "ArrowDown":
            sp.down = true;
            break;
        case "KeyS":
            sp.down = true;
            break;
        case "KeyJ":
            sp.punch = true;
            break;
        case "KeyK":
            sp.kick = true;
            break;
        case "KeyL":
            sp.special = true;
            break;
        default:
            console.log(ev.code);
    }

}
function canvasKeyUpHandler(ev,personagem){
    let sp = personagem.spriteCurr;
    switch (ev.code) {
        case "ArrowLeft":
            sp.left = false;
            break;
        case "KeyA":
            sp.left = false;
            break;
        case "ArrowRight":
            sp.right = false;
            break;
        case "KeyD":
            sp.right = false;
            break;
        default:
            console.log(ev.code);
    }
}
