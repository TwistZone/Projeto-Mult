"use strict";

(function()
{
    window.addEventListener("load", main);
}());
var spAnterior;
var kickLoops=0;
var punchLoops=0;
var defLoops = 0;
var walkRightLoops = 0;
var walkLeftLoops = 0;
var walkLoops = 0;
var jumpLoops = 0;
var specialLoops = 0;
function main() {
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");  //get content
    var personagem = new Personagem("Psicologia", "right");
    var charArray = personagem.sprites;
    canvas.addEventListener("initend", initEndHandler);
    init(ctx, charArray);  //carregar todos os componentes


    function initEndHandler(ev) {
        //instalar listeners das teclas
        window.addEventListener('keyup', kuh);
        window.addEventListener('keydown', kdh);
        charArray = ev.spArray;
        spAnterior = charArray[7];
        startAnim(ctx,charArray)
    }

    var kuh = function (ev) {
        canvasKeyUpHandler(ev, charArray);
    };
    var kdh = function (ev) {
        canvasKeyDownHandler(ev, charArray);
    };
}
function draw(ctx, sprite)
{
        sprite.draw(ctx);
}
function startAnim(ctx, charArray)
    {
        draw(ctx,charArray[7]);
        animLoop(ctx, charArray);
    }
function init(ctx,chArray) {

    var nLoad = 0;
    var totLoad = chArray.length;
    var imgArray = new Array(totLoad);
    var n = 0;
    for (let i = 0; i < totLoad; i++) {
        imgArray[i] = new Image();
        imgArray[i].addEventListener("load", imgLoadedHandler);
        imgArray[i].id = n++;
        imgArray[i].src = chArray[i];
    }


    //var som to add later


    function imgLoadedHandler(ev) {
        var img = ev.target;
        var nw = img.naturalWidth;
        var nh = img.naturalHeight;
        imgArray[img.id] = new SpriteImage(500, 325, nw /3, nh /3, 1, img);
        nLoad++;
        if (nLoad == totLoad) {
            var ev2 = new Event("initend");
            ev2.spArray = imgArray;
            ctx.canvas.dispatchEvent(ev2);
        }
    }
}

function animLoop(ctx, spArray)
{
    punchLoops++;
    kickLoops++;
    defLoops++;
    jumpLoops++;
    specialLoops++;
    walkLoops++;
    walkRightLoops++;
    walkLeftLoops++;
    var al = function(time)
    {
        animLoop(ctx, spArray);
    };
    var reqID = window.requestAnimationFrame(al);

    render(ctx, spArray,reqID);
}

function render(ctx, charArray,reqID) {
    var cw = ctx.canvas.width;
    var ch = ctx.canvas.height;
    var sp = spAnterior;

    var normal = charArray[7];
    var punchArray = [];
    var kickArray = [];
    ctx.clearRect(0, 0, cw, ch);
    //console.log(sp.kick + "PONTAPE");
    //console.log(sp.punch + "MURRO");
    console.log(sp);

    for (let i = 4; i <= 6; i++)
        punchArray.push(charArray[i]);
    for (let i = 8; i <= 12; i++)
        kickArray.push(charArray[i]);
        if(sp.left && sp.x >0){
            if(spAnterior === normal) {
                sp = charArray[1];
                sp.x -= sp.speed;
                spAnterior = sp;
        }
            else if(spAnterior === charArray[0]) {
                sp = charArray[1];
                sp.x -= sp.speed;
                spAnterior = sp;
        }
            else if(spAnterior === charArray[1]) {
                sp = charArray[0];
                sp.x -= sp.speed;
                spAnterior = sp;
            }
        }
     else if (sp.right && sp.x < cw) {

            if (spAnterior === normal) {
                sp = charArray[0];
                sp.x += sp.speed;
                spAnterior = sp;
            } else if (spAnterior === charArray[0]) {
                sp = charArray[1];
                sp.x += sp.speed;
                spAnterior = sp;
            } else if (spAnterior === charArray[1]) {
                sp = charArray[0];
                sp.x += sp.speed;
                spAnterior = sp;
            }
        }
    if (sp.up && sp.y > 0) {
        sp= charArray[13];
        if (sp.y < sp.yIni)
                sp.y -= sp.speed;
        if(sp.y > ch )
                sp.y += sp.speed;
        if(sp.y === sp.yIni){
            sp.up = false;
            sp = normal;
            spAnterior = sp;
        }
    }
    if (sp.down) {
        if(defLoops === 20){
            sp = charArray[3];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.down = true;
        }
        else if (defLoops === 40){
            sp = normal;
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.down = true;
        }
        else if(defLoops > 40)
            spAnterior.down = false;
            sp.down = false;
    }
   else defLoops = 0;
    if (sp.kick) {
        console.log("posiçao x pontape" + sp.x);
        if (kickLoops === 5) {
            sp = kickArray[0];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        }

        else if (kickLoops === 10) {
            sp = kickArray[1];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 15) {
            sp = kickArray[2];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 20) {
            sp = kickArray[3];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 25) {
            sp = kickArray[4];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 40) {
            sp = kickArray[3];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 45) {
            sp = kickArray[2];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 50) {
            sp = kickArray[1];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        } else if (kickLoops === 55) {
            sp = kickArray[0];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        }
        else if(kickLoops === 60){
            sp = normal;
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.kick = true;
        }
        else if (kickLoops > 60)  {
            spAnterior.kick = false;
            sp.kick = false;
        }
    }
    else             kickLoops = 0;
    if (sp.punch) {


        if (punchLoops === 8) {
            sp = punchArray[0];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.punch = true;
        }
        else if (punchLoops === 16) {
            sp = punchArray[1];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.punch = true;
        }
        else if (punchLoops === 24) {
            sp = punchArray[2];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.punch = true;
        }
        else if (punchLoops === 40){
            sp = punchArray[1];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.punch = true;
        }
        else if (punchLoops === 48) {
            sp = punchArray[0];
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.punch = true;
        }
        else if(punchLoops === 56){
            sp=normal;
            sp.x = spAnterior.x;
            spAnterior = sp;
            spAnterior.punch = true;
        }
        else if(punchLoops > 56){
            spAnterior.punch = false;
            sp.punch = false;
    }
    }
    else       punchLoops = 0;

    draw(ctx,sp);
}
function canvasKeyDownHandler(ev,spArray) {
    let sp = spAnterior;
    switch (ev.code) {
        case "ArrowLeft":
            sp.left = true;
            break;
        case "KeyA":
            sp.left = true;
            break;
        case "ArrowRight":
            sp.right = true;
            break;
        case "KeyD":
            sp.right = true;
            break;
        case "ArrowUp":
            sp.up = true;
            break;
        case "KeyW":
            sp.up = true;
            break;
        case "ArrowDown":
            sp.down = true;
            break;
        case "KeyS":
            sp.down = true;
            break;
        case "KeyJ":
            sp.punch = true;
            break;
        case "KeyK":
            sp.kick = true;
            break;
        default:
            console.log(ev.code);
    }

}
function canvasKeyUpHandler(ev,spArray){
    let sp = spAnterior;
    switch (ev.code) {
        case "ArrowLeft":
            sp.left = false;
            break;
        case "KeyA":
            sp.left = false;
            break;
        case "ArrowRight":
            sp.right = false;
            break;
        case "KeyD":
            sp.right = false;
            break;
        default:
            console.log(ev.code);
    }
}
