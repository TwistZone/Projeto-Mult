class Personagem{
    constructor(nome,lado) {
        this.nome=nome;
        this.lado=lado;
        this.sprites=this.getRightSprites(nome);
    }
    getRightSprites(nome){
        var facArray=[];
        var folder ="sprites" + nome + "/";
        facArray.push(folder+"andar1"+".png"); //0
        facArray.push(folder+"andar2"+".png"); //1
        facArray.push(folder+"ataqueEspecial"+".png"); //2
        facArray.push(folder+"defesa"+".png"); //3

        for(let i=1;i<=3;i++){
            facArray.push(folder +"murro" +i.toString() +".png") // 4 5 6
        }

        facArray.push(folder +"normal"+".png"); // 7

        for(let i=1;i<=5;i++){
            facArray.push(folder+"pontape"+i.toString() +".png") // 8 9 10 11 12
        }
        facArray.push(folder +"salto"+".png"); // 13
        return facArray;
    }
}