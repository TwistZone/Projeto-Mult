"use strict";

(function () {
    window.addEventListener("load", main);
}());

