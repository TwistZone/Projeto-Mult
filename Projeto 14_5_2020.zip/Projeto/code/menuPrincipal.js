"use strict";


(function () {
    window.addEventListener("load", main);
}());

function main() {
    var conquistas = document.getElementById("conquitas");
    var creditos = document.getElementById("creditos");
    var definicoes = document.getElementById("definicoes");
    var jogar = document.getElementById("jogar");
    var sair = document.getElementById("sair");

    conquistas.addEventListener("click" , conquistasPage);
    creditos.addEventListener("click" , creditosPage);
    definicoes.addEventListener("click" , definicoesPage);
    jogar.addEventListener("click" , jogarPage);
    sair.addEventListener("click" , sairPage);

}

function sairPage(ev) {
    window.close();
}

function conquistasPage(ev) {
    var frm = document.getElementsByTagName("iframe")[0];
    frm.src = "conquitas.html";
}

function creditosPage(ev) {
    var frm = document.getElementsByTagName("iframe")[0];
    frm.src = "creditos.html";
}

function definicoesPage(ev) {
    var frm = document.getElementsByTagName("iframe")[0];
    frm.src = "Definicoes.html";
}

function jogarPage(ev) {
    var frm = document.getElementsByTagName("iframe")[0];
    frm.src = "characterSelect.html";
}